# unmcpk
Decryption NetEase Minecraft MCPK implementation written using Go
