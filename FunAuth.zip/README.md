# FunAuth

FunAuth 是一个使用 Golang 编写的轻量级 Bunker 服务实现

支持进入
- 租赁服 (Rental Game)
- 我的山头 (Domain Game)
- 本地联机 (Tan Lobby)
- 联机大厅 (Online Lobby)
- 网络游戏 (Network Game)
- 主城乐园 (Main City)
