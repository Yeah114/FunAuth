package handlers

const fixedCookie = `{
  "sauth_json": "{\"gameid\":\"x19\",\"login_channel\":\"netease\",\"app_channel\":\"netease\",\"platform\":\"pc\",\"sdkuid\":\"aibgrdh3b2ir3djs\",\"sessionid\":\"1-eyJzIjogImM2bnk5OHJ4Zmd1Y3dtd3l6MmpmcDhqcWN2cTd1eTRqIiwgIm9kaSI6ICJhbWF3cmRhYWF3dHJycXFkLWQiLCAic2kiOiAiYTU5YTI5YWUyMzBkNDJiNDBiYmVhMDJiMGQ1OWY0MjIwMDAxNGMwYiIsICJ1IjogImFpYmdyZGgzYjJpcjNkanMiLCAidCI6IDIsICJnX2kiOiAiYWVjZnJ4b2R5cWFhYWFqcCJ9\",\"sdk_version\":\"3.9.0\",\"udid\":\"qi3cb7zjphofpuzufarv0ahn1gydtisy\",\"deviceid\":\"amawrdaaawtrrqqd-d\",\"aim_info\":\"{\\\"aim\\\":\\\"127.0.0.1\\\",\\\"country\\\":\\\"CN\\\",\\\"tz\\\":\\\"+0800\\\",\\\"tzid\\\":\\\"\\\"}\",\"client_login_sn\":\"68560C1E261792555255E1B6DA1990E8\",\"gas_token\":\"\",\"source_platform\":\"pc\",\"ip\":\"127.0.0.1\"}"
}
`
