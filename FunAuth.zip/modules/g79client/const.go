package g79client

const (
	GameVersion = "1.21.2"
)